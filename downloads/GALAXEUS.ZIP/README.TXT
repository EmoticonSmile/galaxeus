
                            Welcome to GALAXEUS!

Please take a moment to read this README; it may offer some guidance should
you encounter any difficulties. 

There is no setup required. Just run

    GALAXEUS.COM

at the DOS prompt in the game directory, or double-click GALAXEUS.COM under
Windows 3.x or Windows 95/98, and you are ready to begin your journey.


                                *** Keys ***

GALAXEUS uses the default MAME keyboard controls:

    Key             Action
    ------------------------------------------------
    1               1 Player
    2               2 Players
    5, 6            Insert Coin
    Space, Ctrl     Fire Ship's Missile
    Left, Right     Move Ship


GALAXEUS-specific keys:

    Key             Action
    ------------------------------------------------
    F1              Reset High Score
    F2              Service Screen CRT/TFT Calibration
    ESC             Quit / Rage Quit / Leave Current Screen


 
                           *** Requirements ***

Your system must meet these minimum requirements:

    80386SX 16 MHz
    Sound Blaster or compatible sound card
    Standard VGA card

    Optional features:
    Parallel Port card
    MDA card


GALAXEUS supports all Sound Blaster and compatible cards, including the very
old Sound Blaster 1.0.

Please ensure that the BLASTER environment variable is set in your AUTOEXEC.BAT
to enable sound. If you encounter silence, check this setting. For example, if
your Sound Blaster is configured to use IRQ 5, I/O address 220h, and
DMA channel 1, simply add this line:

    SET BLASTER=A220 I5 D1

You can also provide the Sound Blaster settings directly on the command line.
For example:

    GALAXEUS.COM A220 I5 D1

These settings will be used regardless of whether a %BLASTER% environment
variable is present. Any settings provided on the command line override the
values defined via %BLASTER%, though.

Galaxeus inherently detects the presence of an optional MDA card and will then
automatically send game telemetry and debug data to the text display. This is a
unique feature with a certain coolness factor, and I highly recommend giving it
a try.


                                *** LEDs ***

If LPT ports are found, Galaxeus will assume that there are LEDs connected to
the highest Port and set them accordingly:

    Pin 2 (Data Line D0) Fire Button
    Pin 3 (Data Line D1) One Player
    Pin 4 (Data Line D2) Two Players
    Pin 5 (Data Line D3) Coin Button (Optional, for free play)

    Ground Pins: Pins 18, 19, 20, 21, 22, 23, 24, 25

Visual pinout (Looking at the female PC Backplate)

    13 12 11 10  9  8  7  6  5  4  3  2  1
     o  o  o  o  o  o  o  o  +  +  +  +  o
       o  -  -  -  -  -  -  -  o  o  o  o
      25 24 23 22 21 20 19 18 17 16 15 14

Warning: Be careful when fiddling around with LEDs on the LPT port, as these
ports do not tolerate short circuits and can burn out instantly. Avoid using
onboard ports; it is much safer to use cheap add-on cards. While some sources
claim that certain ports cannot provide enough current to directly light up
LEDs, testing across dozens of cards has shown that every single one was
capable of providing the necessary current.


                           *** DOSBox variants ***

To view the debug/real time game telemetry, start DOSBox-X with a second
monochrome display using:

dosbox-x.exe -display green

Generally GALAXEUS won't run as smoothly under DOSBox as it does on native
hardware. This is due to a fundamental architecture flaw: both DOSBox and
DOSBox-X experience audio stuttering when the emulated frame rate is higher
than the monitor's actual refresh rate. This occurs because the emulator links
video frames and audio data into tight, interdependent chunks.

With these settings, in the DOSBox-<fork>.conf you're on the safe side if the
TFT of the host operating system runs at 60 Hz:
 
vsyncmode       = force
vsyncrate       = 60

                    *** IMPORTANT WARNING & DISCLAIMER ***
------------------------------------------------------------------------------
PLEASE READ BEFORE USING THE TUNING-PARAMETERS DESCRIBED BELOW (/C, /V, /H)

Hardware Risk for Vintage Equipment:
DO NOT attempt to use the /C, /V, or /H tuning parameters on old, rare, or
valuable collector's CRT monitors. Setting these values too aggressively can
physically destroy vintage "fixed sync" CRT hardware. Better use ONLY modern,
robust multisync CRT equipment for testing!

Compatibility Note for TFT/LCD Displays:
Trying modes above 75 Hz on TFT or LCD displays is not recommended. Most modern
flat panels cannot interpret frequencies past 75 Hz and will either go blank,
display an "Out of Range" error, or malfunction entirely.

Use these advanced tuning features at your own risk!
------------------------------------------------------------------------------


                                *** 86Box ***

GALAXEUS runs in 86Box better than under DOSBox, but still not as smoothly as
on native hardware. Somehow, there is always some kind of microstutter when
emulators try to translate the DOS game's native 67 Hz output to the 60 Hz
refresh rate of the host OS TFT monitor - one just can't get rid of it. Another
flaw is that 86Box's cycle emulation shows up to a 40% variance compared to
real hardware.

However, running GALAXEUS at 60 Hz yields a much smoother result on all
emulators:

    GALAXEUS.COM /C0

The /C switch is the pixel clock selector:

/C0 : 25.175 MHz / 60.0 Hz (available on all VGA cards) 
/C1 : 28.322 MHz / 67.4 Hz (available on all VGA cards)  *default for GALAXEUS 
/C2 : External Clock (custom chips on some enhanced SVGA may set 34.500 MHz). 
      -> std VGA cards freeze            
/C3 : Reserved Clock (custom chips on some enhanced SVGA may set 40.000 MHz).
      -> std.VGA cards freeze


                        *** Exotic real Hardware ***

If you are playing on an old portable computer with an LCD or early TFT display,
the display controller may struggle with GALAXEUS's 67 Hz vertical refresh rate.
Again you can start GALAXEUS with the /C0 switch, which forces the VGA to use a
25 MHz pixel clock and a 60 Hz vertical refresh rate:

    GALAXEUS.COM /C0

Note: At 60 Hz GALAXEUS will run slower (about 11%), because its internal
timing is synchronized to the display's vertical refresh. But at least it runs.
:-)


                         *** Testing the limits ****

On the other hand, you may want to explore the maximum that your card and
display are capable of.

You can increase the H-sync via the /Hx switch. The horizontal total is reduced
by x character clocks this way: 

    GALAXEUS.COM /H1 will slightly increase it by around 0.71 Hz.

EXAMPLES:

    GALAXEUS.COM /H4   -> Gets you to 70 Hz / 70 FPS on standard VGA
    GALAXEUS.COM /H10  -> Gets you to 75 Hz / 75 FPS on standard VGA

    GALAXEUS.COM /H18  -> Gets you to 80 Hz / 80 FPS on some VGA cards:
                          CRTs only! TFTs will most likely fail
    GALAXEUS.COM /H32  -> Gets you to 88 Hz / 88 FPS on some VGA cards:
                          CRTs only! TFTs will most likely fail


HARDWARE LIMITATIONS:
---------------------

It depends on your VGA card's VRAM speed, CRT Controller and DAC how high you
can go. However, all VGA cards I tested reached at least 75 Hz before showing
problems. Tests show that one can expect the majority of cards to reach 78 Hz.

During testing, the MCT-VGA-16 (TDVGA 3588 with the TD3588A chipset) was by
far the fastest card. This 16-bit ISA VGA pushed a solid 89 Hz / 89 FPS on CRT
on my slow 80386SX test bench - completely free of stutter or visual
distortion. Delivering that level of performance on a 386SX is extraordinarily
fast.

Nevertheless, all TFTs I tested were incapable of interpreting a V-sync faster
than 75 Hz. Therefore, I recommend trying to max out the settings only on
modern multisync CRTs.


                      *** Higher Vertical Resolutions ***

    GALAXEUS.COM /V1 -> Increases the resolution from 544 x 480 to 544 x 481.

    GALAXEUS.COM /Vx -> Generally adds x scanlines to the standard
                        480 vertical resolution.

Note on values: Settings where x > 1 should only be used for testing purposes.
A resolution of 482 or higher does not leave enough video memory to maintain
two full frame pages. As a result, the upper part of the next frame will begin
to show up at the lower border of the screen.


                              *** CPU Speed ***

The program runs a small benchmark at startup and refuses to launch GALAXEUS
if the system is incapable of running at least 1014 cycles/ms. Force it to
ignore this with the /I switch:

    GALAXEUS.COM /I -> Ignore CPU benchmark result at startup

This may crash the system if it is too slow to handle the IRQ frequencies.
However, you can still give it a try.



                       ---- A JOURNEY INTO MY PAST ----

It was the countryside in autumn 1982. By six o'clock the light was gone, the
footpaths were wet with rain, and the streets reflected the lamplight. Jackets
hung damp in the wardrobe, and well-worn boots stood on the doormat. TVs made
the windows flicker blue in the evening.

And everything was slower.

Nothing much ever happened in our quiet corner of the world, until a small
 machine arrived in the kid's bedroom - connected to an old black-and-white
TV from a mail-order catalogue with a cheap coax cable. When we switched it
on, the picture rolled until it stopped, and then the cursor sat there like
a door to another world left half open.

The cassette keys clicked. The tape hissed. We watched the loading bars on
the screen, heads together, warm sweaters smelling of autumn and rain.
Tension rose. Then came letters. Then grainy pictures. Then a kind of beepy
music.

A spaceship moved when you pressed a key. A Manic Miner journeyed through
ancient caverns. A star fell through the dark, looping on your own binary
spell.

It was closer to real magic than it would ever be again.

And nobody knew a new era was coming. It just arrived like a weather front,
inside catalogues and carried home in cardboard boxes. Suddenly it was all
around. We still had to do our homework, and school started early, but the
evenings became longer inside that little television glow. The world was
becoming smaller and bigger at the same time, unknowingly expanding right
there on our bedroom desk.

I learned the patience of cassette tapes and the prayer of LOAD "". I learned
that counting starts from zero, and that trial and error is often the best way
to understand something. I typed in what the computer magazines printed and
learned by watching how more gifted fellows practiced their craft.

There was a real closeness to it: your ear pressed against the case, listening
to the tape drive spin, feeling the machine getting warm under your hands, and
the static aura of the TV's glass screen almost touching your nose.

These November evenings stayed with me throughout my life: that first-time
brightness, and the way a small screen could make a little room feel like open
space.

Copied tapes went from hand to hand like forbidden treasures. Children with
wealthier or more generous (grand)parents had floppy disk drives, which most
of us looked on with envy.

Nevertheless the mighty arcade machines in the greasy German fries joints
(Pommesbuden) always played in a league of their own. At home, we only
got pale imitations, clumsy downgrades that never came close to that
arcade-grade quality.

So I always wondered:

If you just tried hard enough, if you pushed the machine to its absolute
limit, couldn't you achieve that arcade perfection right there on your own desk?

GALAXEUS grew out of exactly that feeling.

I wanted absolute control: the fluid motion, the clean shot - and I wanted to
understand the machine from its roots. Assembler was the only way to go:

Direct. Optimized with OCD-level attention to the detail. Every single line of
code so close to the hardware that you can almost feel its heartbeat.

I am incredibly happy with the result: the entire executable is only 55.1 KB,
and it is fast. Very fast indeed. It easily runs at 544 x 480 at 67 Hz/67 FPS
on the slowest 80386 you can find.

Every piece of hardware I tested easily maintained a steady 75 Hz / 75 FPS
without any lag or stutter. However, since the speed scales directly with
the framerate, I locked it by default at 67 Hz to preserve the exact pace
of the gameplay the engine was designed for.

Decades of coding tricks discovered since those early days are woven into every
line of code. Even an 80386SX running at 16 MHz delivers this smooth
performance.

The gameplay is simple: guide the ship with the cursor keys, fire wisely and
sparingly, and write your initials into the high score table.

Enjoy the 80s feeling I have tried to recreate with all my heart.

Your thoughts and comments are always welcome, so please feel free to reach out
by email.

    pling.core@gmx.de

               ---- SOME LAST WORDS ABOUT THE SOURCE CODE ----

No high-level programming language was used for GALAXEUS. It is all Assembly,
even the sprite definitions. I wrote custom tools that generate ASM include
files from sprite definitions done in ASCII, as well as include files containing
the binary sound samples as DB sequences that the compiler could use directly.

The compiler is MASM, as NASM was not around in the 90s when this project was
started. I tried using AI to convert the MASM code to NASM. Oh my... no way.
It cannot be converted automatically; it has to be done by hand - even though
there are no macros involved.

In the end, I spent three months commenting the code in a professional manner.
Surely, it already had plenty of comments, but they were written in a private,
gibberish mix of German and English that I definitely didn't want to publish.
And let's be honest, you have to comment Assembly like nothing else. Without
it, looking back at code you spent two weeks wrestling with five years ago
feels like trying to decipher alien technology from the Roswell UFO.

But documentation is hard work, so a few years ago I discovered something: if
you sneak jokes into the comments, the repetitive work actually becomes fun.
You're not writing a reference manual anymore.

You're writing a comedy.

You actually get hooked, constantly looking for potential for a good, crude
joke buried in the logic. Take this one, for example:

; No branches, no pipeline flushes - shit flows so clean through the
; CPU's plumbing you can hear it whistle.

If you find this funny, go check out the source code. If you don't, you're
probably better off just playing the game, lol.

I will release the source code, but not right now. I'd like to keep the option
open for a future YouTube assembly tutorial series, where I might walk through
some of the key procedures and some rather unusual techniques used in GALAXEUS.

Getting this level of performance out of an old uncached 386SX required
bypassing standard BIOS/DOS limitations and academic Assembly textbook fluff.
I used some rather quirky and aggressive programming techniques like:

- Extensive Self-Modifying Code (SMC): eliminating slow branches and
  minimizing the binary footprint.
- Opcode misalignment: jumping directly into the middle of instructions for
  dual-purpose execution.
- Embedded variables: storing variables directly in the code stream to save
  critical memory bandwidth.
- Heavy use of the somehow nearly forgotten Parity Flag.
- The undocumented SALC opcode: replacing conditional branches by logic.
- PIT manipulation: driving the PIT (Programmable Interval Timer)
  up and down like crazy.
- CPU halting: completely halting the CPU (HLT) when there is nothing to do.
- Stack hijacking: Using the CPU stack for high-speed bookkeeping of dirty
  VRAM bytes.
- VRAM optimization: fast alignment detection for optimized word reads and
  writes to VRAM.
- Custom VGA mode: completely dropping low-resolution Mode X and customizing
  high-resolution planar mode for 544x480 @ 67 Hz

The entire monolithic binary is currently only 55.1 KB. This includes all
game logic, graphics, and full 11 kHz 8-bit digital audio samples for the
Sound Blaster. If you drop the sample data the game engine is 12.5 KB solely.
(just a little bigger than this README)

For the sound, I completely opted out of FM synthesis, as I always found its
distinctive tone slightly weird and depressing. Digital samples are the only way
to bring that authentic, high-energy arcade vibe!

Just know GALAXEUS was the absolute best I could do when it comes to Real Mode
Assembly. I couldn't have done it any better in a thousand lifetimes.


Greetings from Germany, 30.09.2026

Stephan Riediger (Pling)